웹서버 연습용
====

----작성기술----
1. 백엔드 (Node js로 작성)
2. 프론트엔드 (HTML, CSS, Javascript, jQuery 사용)
3. DB (mysql, Sequelize 사용)
- - - -
---페이지 구성---
1. index 페이지
2. 로그인/회원가입 페이지
3. mypage
3. Abuout us 페이지
4. Practice 페이지
5. Commuity 페이지
- - - -
----주요 기술----
1. 프론트에서 작성된 코드를 백엔드에서 컴파일 (gcc, java, python 컴파일러 이용)
2. 비밀번호 암호화 (sha256 모듈 이용)
3. node js ORM 중 하나인 Sequelize로 DB 작성
4. 웹 크롤링, 챗봇기능 ( 업데이트 예정 )
